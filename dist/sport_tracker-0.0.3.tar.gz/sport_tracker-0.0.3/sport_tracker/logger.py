from logging import getLogger

logger = getLogger('sport-tracker')
